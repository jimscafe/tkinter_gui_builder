# Same as sample_2 but using new width, height and coordinate libraries

# Create the library files as needed

from s2a_widgets import label1_1, label1_2, label2_1, label2_2, button1, button2, button3, exit_button


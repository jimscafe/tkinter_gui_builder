# Test the libraries for layout options
# See container.py for all options
import tkinter as TK
import place_functions as pf

#from s2_widgets import label1_1, label1_2, label2_1, label2_2, button1, button2, button3, exit_button
from widget import WG, TestWidget
from container import CT, VB,VC,VT,HAS,HC, HL, HIN,HR,WEX,WIN,WAS,HEX,ROW,BOTTOM,COLUMN, TestContainer
from build import calculate_coordinates, create_widgets

import sys

label1 = WG()
label1.name = 'Label 1'
label1.id = 'label_1'
label1.text = 'Label 1'

label2 = WG()
label2.name = 'Label 2'
label2.id = 'label_2'
label2.text = 'Label 2'

def create_label(name, width, height):
    label = TestWidget()
    label.name = name
    label.id = name
    label.text = name
    label.parent = None
    label.width = width
    label.height = height
    label.x = -1
    label.y = -1
    label.children = []
    return label

def create_container(name, type, children):
    a = TestContainer() # Blank object
    a.children = children
    a.type = type
    a.name = name
    a.parent = None
    a.width = -1
    a.height = -1
    a.x = -1
    a.y = -1
    a.child_h_padding = [0,0]
    a.child_v_padding = [0,0]
    return a

def set_a():
    label1.width = 100
    label2.width = 50
    label1.height = 30
    label2.height = 20
    a = TestContainer() # Blank object
    a.children = [label1, label2]
    a.type = ROW
    a.name = 'TestRow'
    a.child_h_padding = [20, 10, 30]
    return a

def test_width_one():
    # Horizontal testing
    # Individual width
    a = set_a()
    a.width_type = WIN
    a.width = -1
    set_container_child_widths(a)
    print ('a width(210)     :', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 210 and label1.width == 100 and label2.width == 50

def test_width_two():
    # Horizontal testing
    # All same width
    a = set_a()
    a.width_type = WAS
    a.width = -1
    set_container_child_widths(a)
    print ('a width(260)     :', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(100 ):', label2.width)
    assert a.width == 260 and label1.width == 100 and label2.width == 100

def test_width_three():
    # Horizontal testing
    # Individual width
    a = set_a()
    a.width_type = WIN
    a.width = 300
    set_container_child_widths(a)
    print ('a width(300)     :', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 300 and label1.width == 100 and label2.width == 50

def test_width_four():
    # Column
    # Individual width
    print ('Column, two labels, Indidiual width settings, gap either side of each label')
    a = set_a()
    a.width_type = WIN
    a.width = -1
    a.type = COLUMN
    a.child_h_padding = [25, 40]
    set_container_child_widths(a)
    print ('a width(165)     :', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 165 and label1.width == 100 and label2.width == 50

def test_width_five():
    # Column
    # Individual width
    print ('Column, two labels, All widgets same width, gap either side of each label')
    a = set_a()
    a.width_type = WAS
    a.width = -1
    a.type = COLUMN
    a.child_h_padding = [25, 40]
    set_container_child_widths(a)
    print ('a      width(165):', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 165 and label1.width == 100 and label2.width == 100

def test_width_six():
    # Column
    # Expand
    print ('Column, two labels, All widgets expand to container width - use largest widget as width')
    a = set_a()
    a.width_type = WEX
    a.width = -1
    a.type = COLUMN
    a.child_h_padding = [25, 40]
    set_container_child_widths(a)
    print ('a      width(165):', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 165 and label1.width == 165 and label2.width == 165

def test_width_seven():
    # Column
    # Expand
    print ('Column, two labels, All widgets expand to container width - use container width')
    a = set_a()
    a.width_type = WEX
    a.width = 300
    a.type = COLUMN
    a.child_h_padding = [25, 40]
    set_container_child_widths(a)
    print ('a      width(165):', a.width)
    print ('label1 width(100):', label1.width)
    print ('label2 width(50 ):', label2.width)
    assert a.width == 300 and label1.width == 300 and label2.width == 300

def test_height_one():
    print ('Column, two labels, Individual heights (30,20)')
    a = set_a()
    a.height = -1
    a.height_type = HIN
    a.type = COLUMN
    a.child_v_padding = [25, 5, 40]
    set_container_child_heights(a)
    height_print(a, 120, 30, 20)
    assert a.height == 120 and label1.height == 30 and label2.height == 20

def test_height_two():
    print ('Column, two labels, Labels same height, tallest widget heights (30,20)')
    a = set_a()
    a.height = -1
    a.height_type = HAS
    a.type = COLUMN
    a.child_v_padding = [25, 5, 40]
    set_container_child_heights(a)
    height_print(a, 130, 30, 30)
    assert a.height == 130 and label1.height == 30 and label2.height == 30

def test_height_three():
    print ('Column, two labels, Individual heights (30,20) container height 150')
    a = set_a()
    a.height = 150
    a.height_type = HIN
    a.type = COLUMN
    a.child_v_padding = [25, 5, 40]
    set_container_child_heights(a)
    height_print(a, 150, 30, 20)
    assert a.height == 150 and label1.height == 30 and label2.height == 20

def test_height_four():
    print ('Row, two labels, Individual heights (30,20)')
    a = set_a()
    a.height = -1
    a.height_type = HIN
    a.type = ROW
    a.child_v_padding = [25, 40]
    set_container_child_heights(a)
    height_print(a, 95, 30, 20)
    assert a.height == 95 and label1.height == 30 and label2.height == 20

def test_height_five():
    print ('Row, two labels, Sane heights heights (30,20)')
    a = set_a()
    a.height = -1
    a.height_type = HAS
    a.type = ROW
    a.child_v_padding = [25, 40]
    set_container_child_heights(a)
    height_print(a, 95, 30, 30)
    assert a.height == 95 and label1.height == 30 and label2.height == 30

def test_height_six():
    print ('Row, two labels, Expand Height (30,20)')
    a = set_a()
    a.height = -1
    a.height_type = HEX
    a.type = ROW
    a.child_v_padding = [25, 40]
    set_container_child_heights(a)
    height_print(a, 95, 95, 95)
    assert a.height == 95 and label1.height == 95 and label2.height == 95

def test_height_seven():
    print ('Row, two labels, Expand Height (30,20) container height = 150')
    a = set_a()
    a.height = 150
    a.height_type = HEX
    a.type = ROW
    a.child_v_padding = [25, 40]
    set_container_child_heights(a)
    height_print(a, 150, 150, 150)
    assert a.height == 150 and label1.height == 150 and label2.height == 150

def height_print(node, a,b,c):
    print ('a      height({}):'.format(a), node.height)
    print ('label1 height({}):'.format(b), node.children[0].height)
    print ('label2 height({}):'.format(c), node.children[1].height)

def test_complex_width():
    print ('Test complex width, needing double travers')
    l1 = create_label('Label 1', 100, 10)
    l2 = create_label('Label 2', 50, 10)
    c1 = create_container('con 1', ROW, [l1,l2])
    c1.child_h_padding = [20,10,20]
    c1.width_type = WIN
    #traverse_tree(c1, print_node)
    #print ('-'*70)
    #set_container_child_widths(c1)
    #traverse_tree(c1, print_node)
    l3 = create_label('Label 3', 100, 10)
    c2 = create_container('con 2', ROW, [l3])
    c2.child_h_padding = [20,10]
    c2.width_type = WIN
    #print ('-'*70)
    #set_container_child_widths(c2)
    #traverse_tree(c2, print_node)
    c3 = create_container('con 3', COLUMN, [c1, c2])
    c3.child_h_padding = [0,0]
    c3.width_type = WEX
    #traverse_tree(c3, set_container_child_widths)
    #print ('-'*70)
    #traverse_tree(c3, print_node)
    l4 = create_label('Label 4', 150, 10)
    c4 = create_container('con 4', ROW, [l4])
    c4.child_h_padding = [20,10]
    c4.width_type = WIN
    c4.width = 300
    #traverse_tree(c4, set_container_child_widths)
    #print ('-'*70)
    traverse_tree(c4, print_node)
    c5 = create_container('con 5', COLUMN, [c4, c3])
    c5.child_h_padding = [0,0]
    c5.width_type = WEX
    # Not needed for the test, but add heights so that heights can also be calculated
    c1.height_type = HIN
    c1.child_v_padding = [10,10]
    c2.height_type = HIN
    c2.child_v_padding = [10,10]
    c4.height_type = HIN
    c4.child_v_padding = [10,10]
    c3.height_type = HIN
    c5.height_type = HIN
    traverse_tree(c5, set_container_child_widths)
    traverse_tree(c5, set_container_child_heights)
    print ('-'*70)
    traverse_tree(c5, print_node)
    traverse_tree(c5, set_container_child_widths, top_down=True)
    traverse_tree(c5, set_container_child_heights, top_down=True)
    traverse_tree(c5, assign_parent)
    print ('-'*70)
    traverse_tree(c5, print_node)
    assert c1.width == 300 and c2.width == 300

def print_node(obj):
    if obj.parent:
        parent = obj.parent.name
    else:
        parent = 'None'
    print ('{:12} ({:12}) width={:4}: height={:4} : x={:4} : y={:4}'.format(obj.name, parent, obj.width, obj.height, obj.x, obj.y))
    return '' # No error

def traverse_tree(root, process, top_down=False, debug=False):
    # Applies process bottom up
    if top_down:
        append = lambda x,y: x.insert(0,y)
    else:
        append = lambda x,y: x.append(y)
    # append = lambda x,y: x.insert(0,y) # For top down traversing

    ans = ''
    stack = []
    expanded = []
    stack.append(root)
    while stack:
        node = stack[-1]
        if node.name in expanded:
            if debug: print ('Process node', node.name)
            error =  process(node)
            if error:
                ans = error
                break
            stack.pop()
        else:
            # Add children to stack
            if debug: print ('Expand Node:', node.name, node.args)
            if node.children:
                for child in node.children:
                    append(stack, child)
                        #stack.append(child)
            expanded.append(node.name)
    #sys.exit(0)
    return ans

def assign_parent(node):
    if node.children:
        #print ('Parent', node.name)
        for child in node.children:
            #print ('..Child', child.name)
            child.parent = node
    return ''

# ----------------------------------------------------------------------------------------------------------------------
# Widths
# ----------------------------------------------------------------------------------------------------------------------
def set_container_child_widths(node):
    if node.children:
        if node.type == ROW:
            # WIS requires no adjustment
            if node.width_type == WAS:
                # Children widths all set the same (largest)
                children_same_width(node)
            if node.width_type in (WAS, WIN):
                node.width = max(node.width, total_row_width(node.children, node.child_h_padding))
            else:
                print ('Not implemented', node.width_type)
                sys.exit(1)
        elif node.type == COLUMN:
            if node.width_type == WIN:
                # Calculate widest label + gaps
                width = largest_child_width_with_gaps(node)
                #for child in node.children:
                #    width = max(width, node.child_h_padding[0] + child.width + node.child_h_padding[1])
                #print (width)
                node.width = max(node.width, width)
            elif node.width_type == WAS:
                children_same_width(node)
                node.width = max(node.width,  node.child_h_padding[0] + node.children[0].width + node.child_h_padding[1])
            elif node.width_type == WEX:
                for child in node.children:
                    node.width = max(node.width, child.width)
                for child in node.children:
                    child.width = node.width
            else:
                print ('Not implemented', node.width_type)
                sys.exit(1)
        else:
            print ('Node.type not implemented', node.type)
            sys.exit(1)

def total_row_width(children, padding=[0,0]):
    i = 0
    width = padding[i]
    for child in children:
        i += 1
        width += child.width + padding[i]
        padding.append(0)
    return width

def children_same_width(node):
    width = 0
    for child in node.children:
        width = max(width, child.width)
    for child in node.children:
        child.width = width

def largest_child_width_with_gaps(node):
    width = 0
    for child in node.children:
        width = max(width, node.child_h_padding[0] + child.width + node.child_h_padding[1])
    return width

# ----------------------------------------------------------------------------------------------------------------------
# Heights
# ----------------------------------------------------------------------------------------------------------------------
def set_container_child_heights(node):
    if node.children:
        if node.type == COLUMN:
            if node.height_type == HAS:
                # Children widths all set the same (largest)
                children_same_heights(node)
            if node.height_type in (HAS, HIN):
                node.height = max(node.height, total_row_height(node.children, node.child_v_padding))
            else:
                print ('Not implemented', node.height_type)
                sys.exit(1)
        elif node.type == ROW:
            if node.height_type == HIN:
                height = largest_child_height_with_gaps(node)
                node.height = max(node.height, height)
            elif node.height_type == HAS:
                children_same_heights(node)
                node.height = max(node.height,  node.child_v_padding[0] + node.children[0].height + node.child_v_padding[1])
            elif node.height_type == HEX:
                for child in node.children:
                    node.height = max(node.height, child.height)
                for child in node.children:
                    child.height = node.height
            else:
                print ('Not implemented', node.height_type)
                sys.exit(1)
        else:
            print ('Not implemented', node.type, node.height_type)
            sys.exit(1)

def total_row_height(children, padding=[0, 0]):
    i = 0
    height = padding[i]
    for child in children:
        i += 1
        height += child.height + padding[i]
        padding.append(0)
    return height

def children_same_heights(node):
    height = 0
    for child in node.children:
        height = max(height, child.height)
    for child in node.children:
        child.height = height

def largest_child_height_with_gaps(node):
    height = 0
    for child in node.children:
        height = max(height, node.child_v_padding[0] + child.height + node.child_v_padding[1])
    return height


if __name__ == '__main__':
    test_width_one()
    print ('-'*70)
    test_width_two()
    print ('-'*70)
    test_width_three()
    print ('-'*70)
    test_width_four()
    print ('-'*70)
    test_width_five()
    print ('-'*70)
    test_width_six()
    print ('-'*70)
    test_width_seven()
    print ('-'*70)
    test_height_one()
    print ('-'*70)
    test_height_two()
    print ('-'*70)
    test_height_three()
    print ('-'*70)
    test_height_four()
    print ('-'*70)
    test_height_five()
    print ('-'*70)
    test_height_six()
    print ('-'*70)
    test_height_seven()
    print ('-'*70)
    test_complex_width()
from widget import WG
import tkinter as TK

label1_1 = WG()
label1_1.width = 100
label1_1.height = 20
label1_1.name = 'Label 1 1'
label1_1.id = 'label1_1'
label1_1.text = 'Label 1 1'
label1_1.anchor = TK.CENTER

label1_2 = WG()
label1_2.width = 100
label1_2.height = 20
label1_2.name = 'Label 1 2'
label1_2.id = 'label1_2'
label1_2.text = 'Label 1 2'
label1_2.anchor = TK.CENTER

label2_1 = WG()
label2_1.width = 100
label2_1.height = 20
label2_1.name = 'Label 2 1'
label2_1.id = 'label2_1'
label2_1.text = 'Label 2 1'
label2_1.anchor = TK.CENTER

label2_2 = WG()
label2_2.width = 100
label2_2.height = 20
label2_2.name = 'Label 2 2'
label2_2.id = 'label2_2'
label2_2.text = 'Label 2 2'
label2_2.anchor = TK.CENTER

button1 = WG()
button1.width = 100
button1.height = 30
button1.name = 'Button 1'
button1.id = 'button1'
button1.text = 'Button 1'
button1.widgettype = 'Button'

button2 = WG()
button2.width = 100
button2.height = 30
button2.name = 'Button 2'
button2.id = 'button2'
button2.text = 'Button 2'
button2.widgettype = 'Button'

button3 = WG()
button3.width = 100
button3.height = 30
button3.name = 'Button 3'
button3.id = 'button3'
button3.text = 'Button 3'
button3.widgettype = 'Button'

exit_button = WG()
exit_button.width = 100
exit_button.height = 30
exit_button.name = 'Quit'
exit_button.id = 'quit'
exit_button.text = 'Quit'
exit_button.widgettype = 'Button'
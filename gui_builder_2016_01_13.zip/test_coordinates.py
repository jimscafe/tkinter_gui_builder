# Test all the various coordinate calculations
from widget import WG, TestWidget
from container import VB,VC,VT,HAS,HC, HL, HIN,HR,WEX,WIN,WAS,HEX,ROW,BOTTOM,COLUMN, TestContainer
from test_widths_heights_layout import create_label, create_container, print_node, traverse_tree
from test_widths_heights_layout import set_container_child_widths, total_row_width, set_container_child_heights
from test_widths_heights_layout import total_row_height
import sys

def create_basic_row():
    l1 = create_label('Label 1', 100, 10)
    l2 = create_label('Label 2', 50, 20)
    c1 = create_container('con 1', ROW, [l1,l2])
    c1.child_h_padding = [20,10,30]
    c1.child_v_padding = [20,10]
    c1.width_type = WIN
    c1.height_type = HIN
    return c1

def create_basic_column():
    l1 = create_label('Label 1', 100, 10)
    l2 = create_label('Label 2', 50, 20)
    c1 = create_container('con 1', COLUMN, [l1,l2])
    c1.child_h_padding = [20,10]
    c1.child_v_padding = [20,10, 30]
    c1.width_type = WIN
    c1.height_type = HIN
    return c1

def test_basic_row_ALL_Options():
    print ('Row with 2 labels, All Combinations')
    print ('Calculate x co-ordinates')
    print ('-'*70)
    con1 = create_basic_row()
    con1.x_align = HL
    #con1.x_align = HC
    #con1.x_align = HR
    con1.y_align = VT
    #con1.width = 220
    traverse_tree(con1, print_node)
    con1.x = 0
    traverse_tree(con1, set_container_child_widths)
    traverse_tree(con1, set_container_child_widths, top_down=True)
    print ('-'*70)
    traverse_tree(con1, print_node)
    calculate_x(con1)
    print ('-'*70)
    traverse_tree(con1, print_node)

    # Now check heights
    print ('-'*70)
    print ('Now calculate y co-ordinates')
    con1.y = 0
    con1.height_type = HIN
    #con1.height_type = HAS
    #con1.height_type = HEX # This sets all y coordinates of children = 0
    #con1.height = 40
    con1.y_align = VT
    con1.y_align = VC
    con1.y_align = VB
    traverse_tree(con1, set_container_child_heights)
    traverse_tree(con1, set_container_child_heights, top_down=True)
    print ('-'*70)
    print (con1.child_v_padding)
    print ('-'*70)
    traverse_tree(con1, print_node)
    calculate_y(con1)
    print ('-'*70)
    print (con1.child_h_padding, con1.type, con1.x_align)
    traverse_tree(con1, print_node)

def test_basic_column_ALL_Options():
    print ('Column with 2 labels, All Combinations')
    print ('Calculate x co-ordinates')
    print ('-'*70)
    con1 = create_basic_column()
    con1.width_type = WIN
    #con1.width_type = WAS
    #con1.width_type = WEX
    con1.x_align = HL
    con1.x_align = HC
    #con1.x_align = HR
    #con1.width = 220
    con1.y_align = VT
    con1.y_align = VC
    con1.y_align = VB
    traverse_tree(con1, print_node)
    con1.x = 0
    con1.y = 0
    traverse_tree(con1, set_container_child_widths)
    traverse_tree(con1, set_container_child_widths, top_down=True)
    print ('-'*70)
    traverse_tree(con1, print_node)
    print ('-'*70)
    print (con1.child_h_padding, con1.type, con1.x_align)
    calculate_x(con1)
    print ('-'*70)
    traverse_tree(con1, print_node)
    traverse_tree(con1, set_container_child_heights)
    traverse_tree(con1, set_container_child_heights, top_down=True)
    print ('-'*70)
    print (con1.child_v_padding, con1.type, con1.y_align)
    #con1.height = 100
    calculate_y(con1)
    print ('-'*70)
    traverse_tree(con1, print_node)

#-----------------------------------------------------------------------------------------------------------------------
# x co-ordinates
#-----------------------------------------------------------------------------------------------------------------------
def calculate_x(node):
    # Calculate x corodinate of node children
    #print (node.child_h_padding)
    if node.children:
        if all_children_have_widths(node):
            if node.type == ROW:
                if node.x_align in [HL, HC, HR]:
                    # Use the padding to set x coordinates
                    i = 0
                    left = node.child_h_padding[0]
                    for child in node.children:
                        child.x = left
                        node.child_h_padding.append(0) # make sure there are enough
                        i += 1
                        left += child.width + node.child_h_padding[i]
                else:
                    print ('Node.x_align not implemented', node.type, node.x_align)
                    sys.exit(1)
                if node.x_align == HC: # Adjust x coordinate if centered
                    left = int((node.children[0].x + node.width - node.children[-1].x - node.children[-1].width) / 2)
                    adjustment = left - node.children[0].x
                    for child in node.children:
                        child.x += adjustment
                if node.x_align == HR: # Adjust x coordinate if right justified
                    # Important if container width set
                    left_total_width = total_row_width(node.children, node.child_h_padding)
                    adjustment = node.width - left_total_width - node.children[0].x
                    for child in node.children:
                        child.x += adjustment
            elif node.type == COLUMN:
                if node.width_type == WEX: # Expand,  all x is 0
                    for child in node.children:
                        child.x = 0
                elif node.x_align == HL: # Each child has y coordinate of padding[0]
                    for child in node.children:
                        child.x = node.child_h_padding[0]
                elif node.x_align == HC:
                    for child in node.children:
                        child.x = int((node.width - child.width)/2)
                elif node.x_align == HR:
                    for child in node.children:
                        child.x = node.width - child.width - node.child_h_padding[1]
                else:
                    print ('Node.x_align not implemented', node.type, node.x_align)
                    sys.exit(1)
            else:
                print ('Node.type not implemented(x)', node.type)
                sys.exit(1)

#-----------------------------------------------------------------------------------------------------------------------
# y co-ordinates
#-----------------------------------------------------------------------------------------------------------------------
def calculate_y(node):
    # Calculate x corodinate of node children
    #print (node.child_h_padding)
    if node.children:
        if all_children_have_heights(node):
            if node.type == ROW:
                if node.height_type == HEX: # Expand all y is 0
                    for child in node.children:
                        child.y = 0
                elif node.y_align == VT: # Each child has y coordinate of padding[0]
                    for child in node.children:
                        child.y = node.child_v_padding[0]
                elif node.y_align == VC:
                    for child in node.children:
                        child.y = int((node.height - child.height)/2)
                elif node.y_align == VB:
                    for child in node.children:
                        child.y = node.height - child.height - node.child_v_padding[1]
                else:
                    print ('Node aligntype not implemented', node.type, node.y_align)
                    sys.exit(1)
            elif node.type == COLUMN:
                if node.y_align in [VT, VC, VB]: #, HC, HR]:
                    # Use the padding to set y coordinates
                    i = 0
                    top = node.child_v_padding[0]
                    for child in node.children:
                        child.y = top
                        node.child_v_padding.append(0) # make sure there are enough
                        i += 1
                        top += child.height + node.child_v_padding[i]
                else:
                    print ('Node.x_align not implemented', node.type, node.x_align)
                    sys.exit(1)
                if node.y_align == VC: # Adjust y coordinate if centered
                    top = int((node.children[0].y + node.height - node.children[-1].y - node.children[-1].height) / 2)
                    adjustment = top - node.children[0].y
                    for child in node.children:
                        child.y += adjustment
                if node.y_align == VB: # Adjust x coordinate if right justified
                    # Important if container width set
                    total_height = total_row_height(node.children, node.child_h_padding)
                    print (total_height)
                    adjustment = node.height - total_height - node.children[0].y
                    for child in node.children:
                        child.y += adjustment
            else:
                print ('Node.type not implemented(y)', node.type)
                sys.exit(1)

def all_children_have_widths(node):
    ans = True
    for child in node.children:
        if child.width < 1:
                ans = False
    return ans

def all_children_have_heights(node):
    ans = True
    for child in node.children:
        if child.height < 1:
                ans = False
    return ans

if __name__ == '__main__':
    test_basic_row_ALL_Options()
    test_basic_column_ALL_Options()